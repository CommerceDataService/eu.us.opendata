# Project EU-US
Joint EU-US R Library focused on extracting data from Eurostat API and BEA API
